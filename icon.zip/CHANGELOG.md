## v1.2.2

- Updated `manifest.json` description
- Updated `manifest.json` dependency `Maygik-MoreHeadUtilities-1.0.9`

## v1.2.1

- Updated `README.md` missing map translations

## v1.2.0

- Reworked `README.md`
- Removed `manifest.json` dependency `XiaohaiMod-XH_DamageShow_EnemyHealthBar-1.0.3`
- Added **APEX Banking** Map
- Reduced the number of spawns for each Tier 3 swarms

## v1.1.1

- Updated `manifest.json` dependency `Arc059-BluePrince-1.3.2`

## v1.1.0

- Added **Enemy_And_Valuable_Spawn_Manager** Mod to remove minecraft items from shop
- Updated `manifest.json` dependency `YMC_MHZ-MoreHead-1.4.3`
- Reversed `manifest.json` dependency list so that it matches the table order in `README.md`

## v1.0.2

- Added Discord link

## v1.0.1

- Updated `README.md` to include MapVote name
- Updated `HeroHanex.NoItemSpawnLimit.cfg`
- Updated `Jettcodey.MoreShopItems.cfg`

## v1.0.0

- First release with 56 mods